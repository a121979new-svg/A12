package com.voltmeterpro.pocof6

import android.app.Activity
import android.os.Bundle
import android.os.BatteryManager
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.os.Handler
import android.os.Looper
import java.util.Locale
import kotlin.math.abs

class MainActivity : Activity() {
    private lateinit var batteryManager: BatteryManager
    private lateinit var voltageView: TextView
    private lateinit var currentView: TextView
    private lateinit var powerView: TextView
    private lateinit var tempView: TextView
    private lateinit var levelView: TextView
    private lateinit var statusView: TextView
    private lateinit var noteView: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val refresh = object : Runnable {
        override fun run() {
            updateReadings()
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        batteryManager = getSystemService(BATTERY_SERVICE) as BatteryManager
        buildUi()
        updateReadings()
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(refresh)
        handler.post(refresh)
    }

    override fun onPause() {
        handler.removeCallbacks(refresh)
        super.onPause()
    }

    private fun buildUi() {
        val bg = Color.rgb(10, 16, 28)
        val panel = Color.rgb(22, 32, 49)
        val white = Color.WHITE
        val muted = Color.rgb(166, 181, 201)
        val green = Color.rgb(74, 222, 128)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(20))
            setBackgroundColor(bg)
        }

        val title = TextView(this).apply {
            text = "VOLTMETER PRO"
            textSize = 23f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        root.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "POCO F6 • LIVE BATTERY MONITOR"
            textSize = 11f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, dp(6), 0, dp(22))
        }
        root.addView(subtitle, matchWrap())

        voltageView = metric(root, "ولتاژ باتری", "— V", panel, green)
        currentView = metric(root, "جریان باتری", "— A", panel, Color.rgb(96, 165, 250))
        powerView = metric(root, "توان محاسبه‌شده باتری", "— W", panel, green)
        tempView = metric(root, "دمای باتری", "— °C", panel, white)
        levelView = metric(root, "سطح شارژ", "— %", panel, white)
        statusView = metric(root, "وضعیت", "در حال خواندن…", panel, white)

        noteView = TextView(this).apply {
            text = "مقادیر از سنسورهای اندروید خوانده می‌شوند. جریان و توان مربوط به خود باتری هستند، نه اندازه‌گیری مستقیم خروجی شارژر."
            textSize = 12f
            setTextColor(muted)
            setLineSpacing(dp(3).toFloat(), 1f)
            setPadding(dp(4), dp(18), dp(4), 0)
        }
        root.addView(noteView, matchWrap())

        val scroll = android.widget.ScrollView(this).apply { addView(root) }
        setContentView(scroll)
    }

    private fun metric(parent: LinearLayout, label: String, initial: String, panel: Int, valueColor: Int): TextView {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setBackgroundColor(panel)
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.bottomMargin = dp(10)
            layoutParams = lp
        }
        val labelView = TextView(this).apply {
            text = label
            textSize = 12f
            setTextColor(Color.rgb(166, 181, 201))
        }
        val valueView = TextView(this).apply {
            text = initial
            textSize = 25f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(valueColor)
            setPadding(0, dp(4), 0, 0)
        }
        card.addView(labelView)
        card.addView(valueView)
        parent.addView(card, matchWrap())
        return valueView
    }

    private fun updateReadings() {
        val intent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        if (intent == null) {
            statusView.text = "اطلاعات باتری در دسترس نیست"
            return
        }

        val voltageMv = intent.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1)
        val tempTenths = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1)
        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val state = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)

        val currentUa = try {
            batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        } catch (_: Exception) { Int.MIN_VALUE }

        if (voltageMv > 0) {
            voltageView.text = String.format(Locale.US, "%.3f V", voltageMv / 1000.0)
        } else voltageView.text = "ناموجود"

        val currentAvailable = currentUa != Int.MIN_VALUE && currentUa != 0
        val voltage = if (voltageMv > 0) voltageMv / 1000.0 else 0.0
        if (currentAvailable) {
            val amps = currentUa / 1_000_000.0
            currentView.text = String.format(Locale.US, "%+.3f A  (%d mA)", amps, currentUa / 1000)
            if (voltage > 0) {
                val watts = abs(amps * voltage)
                powerView.text = String.format(Locale.US, "%.3f W", watts)
            } else powerView.text = "ناموجود"
        } else {
            currentView.text = "در این دستگاه گزارش نمی‌شود"
            powerView.text = "قابل محاسبه نیست"
        }

        tempView.text = if (tempTenths >= 0)
            String.format(Locale.US, "%.1f °C", tempTenths / 10.0) else "ناموجود"
        val pct = if (level >= 0 && scale > 0) (level * 100 / scale) else -1
        levelView.text = if (pct >= 0) "$pct %" else "ناموجود"

        val status = when (state) {
            BatteryManager.BATTERY_STATUS_CHARGING -> "در حال شارژ"
            BatteryManager.BATTERY_STATUS_FULL -> "شارژ کامل"
            BatteryManager.BATTERY_STATUS_DISCHARGING -> "در حال تخلیه"
            BatteryManager.BATTERY_STATUS_NOT_CHARGING -> "متصل، بدون شارژ"
            else -> "نامشخص"
        }
        val source = when (plugged) {
            BatteryManager.BATTERY_PLUGGED_USB -> "USB"
            BatteryManager.BATTERY_PLUGGED_AC -> "آداپتور"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "بی‌سیم"
            else -> "بدون اتصال شارژر"
        }
        statusView.text = "$status • $source"
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
}
